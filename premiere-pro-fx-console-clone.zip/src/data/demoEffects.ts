export type DemoEffect = {
  id: string;
  name: string;
  kind: "video" | "audio" | "preset";
};

// Gerçek eklenti bu listeyi Premiere Pro'nun kendi kataloğundan canlı çeker:
//  - Effects  -> VideoFilterFactory / AudioFilterFactory (mavi nokta)
//  - Presets  -> kullanıcının preset binindeki özel presetler (kırmızı nokta)
// Web demosu için ekran görüntülerindeki öğelerle aynı örnek küme:
export const demoEffects: DemoEffect[] = [
  // ---- Effects (mavi) ----
  { id: "v-fastblur", name: "Fast Blur", kind: "video" },
  { id: "v-ccradialfast", name: "CC Radial Fast Blur", kind: "video" },
  { id: "v-bilateral", name: "Bilateral Blur", kind: "video" },
  { id: "v-box", name: "Box Blur", kind: "video" },
  { id: "v-cameralens", name: "Camera Lens Blur", kind: "video" },
  { id: "v-cccross", name: "CC Cross Blur", kind: "video" },
  { id: "v-ccradial", name: "CC Radial Blur", kind: "video" },
  { id: "v-ccvector", name: "CC Vector Blur", kind: "video" },
  { id: "v-gaussian", name: "Gaussian Blur", kind: "video" },
  { id: "v-directional", name: "Directional Blur", kind: "video" },
  { id: "v-camera", name: "Camera Blur", kind: "video" },
  { id: "v-fractal", name: "Fractal", kind: "video" },
  { id: "v-fractalnoise", name: "Fractal Noise", kind: "video" },
  { id: "v-vrfractal", name: "VR Fractal Noise", kind: "video" },
  { id: "v-lumetri", name: "Lumetri Color", kind: "video" },
  { id: "v-ultrakey", name: "Ultra Key", kind: "video" },
  { id: "v-warp", name: "Warp Stabilizer VFX", kind: "video" },
  { id: "v-sharpen", name: "Sharpen", kind: "video" },
  { id: "v-mos", name: "Mosaic", kind: "video" },
  { id: "v-crop", name: "Crop", kind: "video" },
  { id: "v-transform", name: "Transform", kind: "video" },
  { id: "v-echo", name: "Echo", kind: "video" },
  { id: "v-levels", name: "Levels", kind: "video" },
  { id: "v-tint", name: "Tint", kind: "video" },
  { id: "v-bw", name: "Black & White", kind: "video" },
  { id: "a-reverb", name: "Studio Reverb", kind: "audio" },
  { id: "a-denoise", name: "DeNoise", kind: "audio" },
  { id: "a-vocal", name: "Vocal Enhancer", kind: "audio" },
  { id: "a-param", name: "Parametric Equalizer", kind: "audio" },
  { id: "a-dyn", name: "Dynamics", kind: "audio" },
  // ---- Presets (kırmızı) : kullanıcının preset bininden ----
  { id: "p-angry", name: "Angry Face (Colour)", kind: "preset" },
  { id: "p-bw", name: "B&W", kind: "preset" },
  { id: "p-bluesteel", name: "Blue Steel", kind: "preset" },
  { id: "p-cardwipe", name: "Card Wipe - 2D fractured", kind: "preset" },
  { id: "p-tealorange", name: "Teal & Orange Pop", kind: "preset" },
  { id: "p-filmfade", name: "Film Fade Clean", kind: "preset" },
  { id: "p-shake", name: "Handheld Shake 04", kind: "preset" },
  { id: "p-glow", name: "Soft Glow 35mm", kind: "preset" },
  { id: "p-vhs", name: "VHS Tracking", kind: "preset" },
  { id: "p-voice", name: "Voice Polish Podcast", kind: "preset" },
];

export function scoreAgainst(query: string, text: string): number {
  if (!query) return 0;
  const q = query.toLowerCase();
  const t = text.toLowerCase();
  if (t === q) return 1000;
  if (t.startsWith(q)) return 900;

  const words = t.split(/[\s&/_-]+/).filter(Boolean);
  if (words.some((w) => w.startsWith(q))) return 800;
  if (t.includes(q)) return 650;

  const initials = words.map((w) => w[0]).join("");
  if (initials.includes(q)) return 500;

  let ti = 0;
  for (let qi = 0; qi < q.length; qi++) {
    const idx = t.indexOf(q[qi], ti);
    if (idx === -1) return -1;
    ti = idx + 1;
  }
  return 200;
}
