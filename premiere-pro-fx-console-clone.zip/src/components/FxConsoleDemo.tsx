import { useEffect, useMemo, useRef, useState } from "react";
import { demoEffects, scoreAgainst, type DemoEffect } from "../data/demoEffects";

type Toast = { msg: string; kind: "ok" | "warn" | "err" } | null;

/* ------------------------------------------------------------------ */
/*  FX Palette — tarif dosyasına birebir: 384px bar, Segoe UI,         */
/*  Presets (kırmızı #EF4444) + Effects (mavi #3B82F6), seçim #0078D7  */
/* ------------------------------------------------------------------ */

function Magnifier() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="#A8ACB6" strokeWidth="1.85">
      <circle cx="8.5" cy="8.5" r="5" />
      <line x1="12.4" y1="12.4" x2="17.5" y2="17.5" />
    </svg>
  );
}

function StarIcon({ filled, color }: { filled: boolean; color: string }) {
  return (
    <svg width="10" height="10" viewBox="0 0 24 24" fill={filled ? color : "none"} stroke={color} strokeWidth="2">
      <path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z" strokeLinejoin="round" />
    </svg>
  );
}

function GearIcon() {
  const teeth = Array.from({ length: 8 });
  return (
    <svg width="16" height="16" viewBox="0 0 26 26" fill="none" stroke="currentColor" strokeWidth="1.65">
      <circle cx="13" cy="13" r="3.6" />
      {teeth.map((_, i) => {
        const a = (i * Math.PI) / 4;
        const x1 = 13 + Math.cos(a) * 6.2;
        const y1 = 13 + Math.sin(a) * 6.2;
        const x2 = 13 + Math.cos(a) * 9.4;
        const y2 = 13 + Math.sin(a) * 9.4;
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} strokeLinecap="round" />;
      })}
    </svg>
  );
}

function CameraIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M3 8a1 1 0 011-1h2l1.5-2h7L16 7h4a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1V8z" strokeLinejoin="round" />
      <circle cx="12" cy="13" r="3.4" />
    </svg>
  );
}

function GalleryIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
      <rect x="3.5" y="3.5" width="7" height="7" />
      <rect x="13.5" y="3.5" width="7" height="7" />
      <rect x="3.5" y="13.5" width="7" height="7" />
      <rect x="13.5" y="13.5" width="7" height="7" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M12 3v10m0 0l-3.5-3.5M12 13l3.5-3.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M4 17v2a1 1 0 001 1h14a1 1 0 001-1v-2" strokeLinecap="round" />
    </svg>
  );
}

function SendIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M21 3L10.5 13.5" strokeLinecap="round" />
      <path d="M21 3l-6.8 18-3.7-7.5L3 9.8 21 3z" strokeLinejoin="round" />
    </svg>
  );
}

function tagLabel(e: DemoEffect) {
  if (e.kind === "preset") return "Preset";
  return e.kind === "video" ? "Video" : "Audio";
}

export default function FxConsoleDemo() {
  const [query, setQuery] = useState("blur");
  const [activeFlat, setActiveFlat] = useState(0);
  const [favorites, setFavorites] = useState<string[]>(["v-fastblur", "v-lumetri"]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toast, setToast] = useState<Toast>(null);
  const [closeAfterApply, setCloseAfterApply] = useState(true);
  const [closeOnOutside, setCloseOnOutside] = useState(true);
  const [shortcutCloses, setShortcutCloses] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const toastTimer = useRef<number | null>(null);

  function showToast(msg: string, kind: "ok" | "warn" | "err" = "ok") {
    setToast({ msg, kind });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  }

  const { presetRows, effectRows, presetTotal, effectTotal } = useMemo(() => {
    const q = query.trim();
    if (!q) return { presetRows: [], effectRows: [], presetTotal: 0, effectTotal: 0 };

    // önekler: v: video · a: audio · p: presets
    let scope: "all" | "video" | "audio" | "preset" = "all";
    let rest = q;
    const m = q.match(/^\s*(v|a|p)\s*:\s*(.*)$/i);
    if (m) {
      scope = m[1].toLowerCase() === "v" ? "video" : m[1].toLowerCase() === "a" ? "audio" : "preset";
      rest = m[2];
    }
    if (!rest) return { presetRows: [], effectRows: [], presetTotal: 0, effectTotal: 0 };

    const pool = demoEffects.filter((e) => {
      if (scope === "video") return e.kind === "video";
      if (scope === "audio") return e.kind === "audio";
      if (scope === "preset") return e.kind === "preset";
      return true;
    });

    const scored = pool
      .map((e) => ({ e, score: scoreAgainst(rest, e.name) }))
      .filter((r) => r.score >= 0)
      .sort((a, b) => {
        const fa = favorites.includes(a.e.id) ? 1 : 0;
        const fb = favorites.includes(b.e.id) ? 1 : 0;
        if (fa !== fb) return fb - fa;
        if (b.score !== a.score) return b.score - a.score;
        return a.e.name.localeCompare(b.e.name);
      });

    const presets = scored.filter((r) => r.e.kind === "preset").map((r) => r.e);
    const effects = scored.filter((r) => r.e.kind !== "preset").map((r) => r.e);
    return { presetRows: presets, effectRows: effects, presetTotal: presets.length, effectTotal: effects.length };
  }, [query, favorites]);

  // en fazla 8 satır görünür
  const presetVis = presetRows.slice(0, 8);
  const effectVis = effectRows.slice(0, 8 - presetVis.length);
  const flat: DemoEffect[] = [...presetVis, ...effectVis];
  const listOpen = query.trim().length > 0 && !settingsOpen;

  useEffect(() => {
    setActiveFlat(0);
  }, [query]);

  function applyEffect(effect: DemoEffect, keepOpen?: boolean) {
    showToast(`"${effect.name}" → seçili klibe eklendi`, "ok");
    if (!keepOpen && closeAfterApply) setQuery("");
    else inputRef.current?.focus();
  }

  function toggleFav(id: string, ev: React.MouseEvent) {
    ev.stopPropagation();
    setFavorites((prev) => (prev.includes(id) ? prev.filter((f) => f !== id) : [id, ...prev]));
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveFlat((i) => Math.min(i + 1, flat.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveFlat((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const fx = flat[activeFlat];
      if (fx) applyEffect(fx, e.shiftKey);
    } else if (e.key === "Escape") {
      if (settingsOpen) setSettingsOpen(false);
      else setQuery("");
    }
  }

  // Ctrl+Alt+Space bu alan görünürdeyken arama kutusuna odaklar
  useEffect(() => {
    function handler(ev: KeyboardEvent) {
      if (ev.ctrlKey && ev.altKey && ev.code === "Space") {
        const el = document.getElementById("canli-demo");
        if (!el) return;
        const r = el.getBoundingClientRect();
        if (r.top < window.innerHeight && r.bottom > 0) {
          ev.preventDefault();
          if (shortcutCloses && document.activeElement === inputRef.current && query) {
            setQuery("");
            (inputRef.current as HTMLInputElement)?.blur();
          } else {
            setSettingsOpen(false);
            inputRef.current?.focus();
            inputRef.current?.select();
          }
        }
      }
    }
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [query, shortcutCloses]);

  // dışına tıklayınca kapat (ayar açıksa)
  useEffect(() => {
    if (!closeOnOutside) return;
    function onDocClick(ev: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(ev.target as Node)) {
        setSettingsOpen(false);
      }
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [closeOnOutside]);

  const barBtn =
    "flex h-[26px] w-[26px] items-center justify-center text-[#A2A6B0] hover:bg-[#2B2E36] hover:text-[#E5E7EB]";

  function renderRow(effect: DemoEffect, flatIndex: number) {
    const selected = flatIndex === activeFlat;
    const isFav = favorites.includes(effect.id);
    const starColor = selected ? (isFav ? "#FFE083" : "rgba(255,255,255,0.72)") : isFav ? "#F2B84B" : "#757882";
    return (
      <div
        key={effect.id}
        onClick={() => applyEffect(effect)}
        onMouseEnter={() => setActiveFlat(flatIndex)}
        className="flex h-[31px] cursor-pointer items-center"
        style={{ background: selected ? "#0078D7" : "transparent" }}
        onMouseOver={(ev) => {
          if (!selected) (ev.currentTarget as HTMLDivElement).style.background = "#25272C";
        }}
        onMouseOut={(ev) => {
          if (!selected) (ev.currentTarget as HTMLDivElement).style.background = "transparent";
        }}
      >
        <button
          onClick={(ev) => toggleFav(effect.id, ev)}
          className="flex w-[30px] shrink-0 items-center justify-center"
          style={{ opacity: isFav || selected ? 1 : 0.33 }}
          title="Favori"
        >
          <StarIcon filled={isFav || selected} color={starColor} />
        </button>
        <span
          className="flex-1 truncate pr-2"
          style={{
            fontSize: "13.5px",
            fontWeight: 600,
            color: selected ? "#FFFFFF" : "#F3F4F6",
          }}
        >
          {effect.name}
        </span>
        <span
          className="shrink-0 pr-3"
          style={{
            fontSize: "11px",
            fontWeight: 700,
            color: selected ? "#DBEAFE" : effect.kind === "preset" ? "#FCA5A5" : "#93C5FD",
          }}
        >
          {tagLabel(effect)}
        </span>
      </div>
    );
  }

  function renderGroupHeader(dot: string, title: string, count: number) {
    return (
      <div
        className="flex h-[26px] items-center border-y"
        style={{ background: "#131417", borderColor: "#24262E" }}
      >
        <span className="ml-3 inline-block h-2 w-2 rounded-full" style={{ background: dot }} />
        <span
          className="ml-[14px]"
          style={{ fontSize: "11.5px", fontWeight: 700, color: "#E5E7EB", letterSpacing: "0.04em" }}
        >
          {title}
        </span>
        <span
          className="ml-auto mr-3"
          style={{
            fontSize: "10.5px",
            fontWeight: 700,
            color: count === 0 ? "#565964" : "#9CA3AF",
            fontVariantNumeric: "tabular-nums",
          }}
        >
          {count}
        </span>
      </div>
    );
  }

  const toastStyle =
    toast?.kind === "ok"
      ? { background: "#183629", borderColor: "#2C7A53", color: "#DCFAE9" }
      : toast?.kind === "warn"
        ? { background: "#3B2D17", borderColor: "#A17122", color: "#FDE9C4" }
        : { background: "#3C1C20", borderColor: "#A63A46", color: "#FFD9DD" };

  return (
    <div id="canli-demo" ref={wrapRef} style={{ width: 384, fontFamily: '"Segoe UI", -apple-system, system-ui, sans-serif' }}>
      {/* BAR — 384 × 44 */}
      <div
        className="flex items-center border"
        style={{ width: 384, height: 44, background: "#1E1F22", borderColor: "#32343A" }}
      >
        <div className="flex items-center" style={{ marginLeft: 11 }}>
          <Magnifier />
        </div>
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setSettingsOpen(false);
          }}
          onKeyDown={onKeyDown}
          placeholder="Fx"
          spellCheck={false}
          autoComplete="off"
          className="fx-input border-none bg-transparent outline-none"
          style={{
            width: 200,
            marginLeft: 7,
            fontSize: "14.5px",
            fontWeight: 600,
            color: "#F3F4F6",
          }}
        />
        <div className="ml-auto flex items-center gap-[2px]" style={{ marginRight: 7 }}>
          <button className={barBtn} title="Snapshot" onClick={() => showToast("Snapshot yakında: kare galeriye kaydedilecek", "warn")}>
            <CameraIcon />
          </button>
          <button className={barBtn} title="Galeri" onClick={() => showToast("Galeri yakında", "warn")}>
            <GalleryIcon />
          </button>
          <button className={barBtn} title="Dışa aktar" onClick={() => showToast("Dışa aktarma yakında", "warn")}>
            <DownloadIcon />
          </button>
          <button
            className={barBtn}
            title="Ayarlar"
            onClick={() => setSettingsOpen((s) => !s)}
            style={settingsOpen ? { background: "#2B2E36", color: "#60A5FA" } : undefined}
          >
            <GearIcon />
          </button>
          <button
            className={barBtn}
            title="Uygula"
            onClick={() => {
              const fx = flat[activeFlat];
              if (fx) applyEffect(fx);
              else showToast("Önce bir sonuç seçin", "warn");
            }}
          >
            <SendIcon />
          </button>
        </div>
      </div>

      {/* DROPDOWN */}
      {settingsOpen ? (
        <div className="border border-t-0" style={{ width: 384, height: 152, background: "#1B1C1F", borderColor: "#292B30", padding: 9 }}>
          <div className="flex flex-col gap-[6px]" style={{ fontSize: "11.5px", color: "#D4D6DC" }}>
            {[
              { label: "Close bar after applying effect / preset", value: closeAfterApply, set: setCloseAfterApply },
              { label: "Close bar when clicking outside it", value: closeOnOutside, set: setCloseOnOutside },
              { label: "Shortcut closes bar if already open", value: shortcutCloses, set: setShortcutCloses },
            ].map((row) => (
              <label key={row.label} className="flex h-[18px] cursor-pointer items-center gap-2">
                <span
                  className="flex h-3 w-3 items-center justify-center border text-[9px] leading-none"
                  style={{ borderColor: "#4A4E59", background: row.value ? "#0078D7" : "transparent", color: "#fff" }}
                  onClick={(e) => {
                    e.preventDefault();
                    row.set(!row.value);
                  }}
                >
                  {row.value ? "✓" : ""}
                </span>
                {row.label}
              </label>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            {["Rebuild", "Self-Test", "Clear"].map((b) => (
              <button
                key={b}
                onClick={() => showToast(b === "Clear" ? "Son kullanılanlar temizlendi" : `${b} tamam`, "ok")}
                className="h-[23px] px-3"
                style={{
                  background: b === "Clear" ? "transparent" : "#2B2E35",
                  border: "1px solid #3C4049",
                  borderRadius: 3,
                  fontSize: "11px",
                  color: b === "Clear" ? "#9CA3AF" : "#E5E7EB",
                }}
              >
                {b}
              </button>
            ))}
          </div>
          <div className="mt-2" style={{ fontSize: "10.5px", color: "#6E717A" }}>
            Prefixes:{" "}
            <code className="px-1" style={{ background: "#25272D" }}>v:</code> Video ·{" "}
            <code className="px-1" style={{ background: "#25272D" }}>a:</code> Audio ·{" "}
            <code className="px-1" style={{ background: "#25272D" }}>p:</code> Presets
          </div>
        </div>
      ) : (
        listOpen && (
          <div className="border border-t-0" style={{ width: 384, background: "#18191B", borderColor: "#2B2D34" }}>
            <div className="fx-scroll overflow-y-auto" style={{ maxHeight: 300 }}>
              {flat.length === 0 ? (
                <>
                  {renderGroupHeader("#EF4444", "Presets", 0)}
                  {renderGroupHeader("#3B82F6", "Effects", 0)}
                  <div className="text-center" style={{ padding: "14px 0", fontSize: "12px", color: "#6E717A" }}>
                    no match — try another name
                  </div>
                </>
              ) : (
                <>
                  {(presetVis.length > 0 || presetTotal > 0) && (
                    <>
                      {renderGroupHeader("#EF4444", "Presets", presetTotal)}
                      {presetVis.map((e, i) => renderRow(e, i))}
                    </>
                  )}
                  {(effectVis.length > 0 || effectTotal > 0) && (
                    <>
                      {renderGroupHeader("#3B82F6", "Effects", effectTotal)}
                      {effectVis.map((e, i) => renderRow(e, presetVis.length + i))}
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        )
      )}

      {/* TOAST */}
      {toast && (
        <div
          onClick={() => setToast(null)}
          className="cursor-pointer border"
          style={{ width: 384, marginTop: 6, padding: 12, fontSize: "12.5px", fontWeight: 600, boxShadow: "0 4px 12px rgba(0,0,0,.45)", ...toastStyle }}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}
