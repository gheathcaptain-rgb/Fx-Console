import FxConsoleDemo from "./components/FxConsoleDemo";

const features = [
  {
    title: "Anında arama & uygulama",
    desc: "Efekt adının birkaç harfini yazın, Enter'a basın; efekt seçili klibe anında eklensin. Menülerde kaybolmak yok.",
    icon: "🔎",
  },
  {
    title: "Bulanık (fuzzy) arama",
    desc: "Tam eşleşme, kelime başı, baş harf (gb → Gaussian Blur) ve sıralı alt küme eşleşmesi — FX Console'daki aynı skor mantığı.",
    icon: "🧠",
  },
  {
    title: "Video + Ses efektleri",
    desc: "VideoFilterFactory ve AudioFilterFactory üzerinden Premiere'in TÜM video ve ses efekt kataloğu canlı olarak taranır.",
    icon: "🎛️",
  },
  {
    title: "Favoriler & takma adlar",
    desc: "En çok kullandığınız efektleri favoriye alın, kısa takma adlar (alias) tanımlayın: 'fb' yazınca Fast Blur gelsin.",
    icon: "⭐",
  },
  {
    title: "1-9 hızlı slotlar",
    desc: "Arama kutusu boşken 1-9 tuşlarına basarak o slota atanmış efekti tek tuşla uygulayın.",
    icon: "🔢",
  },
  {
    title: "Gizleme (blacklist)",
    desc: "İhtiyacınız olmayan efektleri sonuçlardan tamamen gizleyin, listeyi sade tutun.",
    icon: "🚫",
  },
  {
    title: "Çoklu klip desteği",
    desc: "Zaman çizelgesinde birden fazla klip seçiliyse efekt hepsine tek seferde uygulanır.",
    icon: "🧩",
  },
  {
    title: "Ayarları taşı",
    desc: "Tüm favoriler, slotlar ve takma adlarınızı tek tıkla panoya kopyalayıp başka bir bilgisayara aktarın.",
    icon: "📋",
  },
];

const comparisonRows = [
  ["Açılış", "Ctrl/Cmd + Space (global, her yerde)", "Panel odaktayken özelleştirilebilir kısayol + menü komutu"],
  ["Arama motoru", "Fuzzy search (tam/baş/alt dize/baş harf)", "Aynı algoritma, Türkçe anahtar kelime genişletmeli"],
  ["Efekt uygulama", "AE Effects & Presets paneline eşdeğer", "Resmi premierepro UXP API'si (VideoFilterFactory/AudioFilterFactory)"],
  ["Favoriler / Alias", "Var", "Var (satır yıldızı + sağ tık)"],
  ["Özel preset grubu", "Preset araması", "🔴 Presets grubu — kaydedilen presetler otomatik listelenir"],
  ["Efekt grubu", "Efekt araması", "🔵 Effects grubu — Premiere kataloğundan canlı"],
  ["Blacklist", "Var", "Var (sağ tık → Gizle)"],
  ["Önek filtreleri", "Yok", "v: video · a: audio · p: presets"],
  ["Snapshot galerisi", "Var", "Planlandı (Exporter.exportSequenceFrame)"],
  ["Platform", "Native eklenti (AE Scripting)", "UXP (Unified Extensibility Platform)"],
  ["Fiyat", "Ücretsiz", "Ücretsiz & açık kaynak"],
];

const installSteps = [
  {
    title: "UXP Developer Tool'u kurun",
    desc: "Creative Cloud Desktop > Diğer Uygulamalar üzerinden \"UXP Developer Tool\"u kurun ve açın.",
  },
  {
    title: "Geliştirici modunu açın",
    desc: "Premiere Pro'da Preferences > Plugins > \"Enable Developer Mode (UXP)\" seçeneğini işaretleyip Premiere'i yeniden başlatın. (Premiere Pro 25.6+ gerekir.)",
  },
  {
    title: "Eklentiyi ekleyin",
    desc: "UXP Developer Tool'da \"Add Plugin\" diyerek indirdiğiniz klasördeki manifest.json dosyasını seçin, ardından Load'a basın.",
  },
  {
    title: "Paneli açın ve sabitleyin",
    desc: "Premiere'de Window > UXP Plugins > FX Console (TR) > FX Console yolunu izleyin, paneli istediğiniz yere dock edin.",
  },
  {
    title: "Kullanmaya başlayın",
    desc: "Bir klip seçin, arama kutusuna efekt adını yazın, Enter'a basın. Hepsi bu kadar.",
  },
];

function SectionTitle({ eyebrow, title, desc }: { eyebrow: string; title: string; desc?: string }) {
  return (
    <div className="mx-auto mb-10 max-w-2xl text-center">
      <span className="text-xs font-semibold uppercase tracking-widest text-violet-400">{eyebrow}</span>
      <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">{title}</h2>
      {desc && <p className="mt-3 text-zinc-400">{desc}</p>}
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#0b0b0f] text-zinc-200 antialiased">
      {/* NAV */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-[#0b0b0f]/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <img src="/images/fxconsole-icon.png" alt="" className="h-8 w-8 rounded-lg" />
            <span className="font-bold text-white">FX Console <span className="text-violet-400">TR</span></span>
          </div>
          <nav className="hidden gap-8 text-sm text-zinc-400 md:flex">
            <a href="#ozellikler" className="hover:text-white">Özellikler</a>
            <a href="#canli-demo" className="hover:text-white">Canlı Demo</a>
            <a href="#kurulum" className="hover:text-white">Kurulum</a>
            <a href="#sinirlar" className="hover:text-white">Sınırlamalar</a>
          </nav>
          <a
            href="/downloads/fx-console-tr-premiere-plugin.zip"
            download
            className="rounded-lg bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-violet-500/20 transition hover:opacity-90"
          >
            Eklentiyi İndir
          </a>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden px-6 pb-20 pt-20 sm:pt-28">
        <div
          className="pointer-events-none absolute inset-0 -z-10 opacity-60"
          style={{
            background:
              "radial-gradient(60% 50% at 50% 0%, rgba(139,92,246,0.25) 0%, rgba(11,11,15,0) 70%)",
          }}
        />
        <div className="mx-auto grid max-w-6xl items-center gap-14 lg:grid-cols-2">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-violet-500/30 bg-violet-500/10 px-3 py-1 text-xs font-medium text-violet-300">
              Ücretsiz · Bağımsız · Resmi UXP API
            </div>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
              After Effects'teki <span className="bg-gradient-to-r from-violet-400 to-cyan-300 bg-clip-text text-transparent">FX Console</span> deneyimi,
              şimdi Premiere Pro'da.
            </h1>
            <p className="mt-5 text-lg text-zinc-400">
              Efekt adını yaz, Enter'a bas, efekt seçili klibe binsin. Menülerde dolaşmaya,
              Efektler panelinde aramaya, sürükle-bırak yapmaya son. FX Console (TR), gerçek
              Premiere Pro UXP API'si üzerine inşa edilmiş bağımsız ve ücretsiz bir eklentidir.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="/downloads/fx-console-tr-premiere-plugin.zip"
                download
                className="rounded-lg bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-500/30 transition hover:opacity-90"
              >
                ⬇ Eklentiyi İndir (.zip)
              </a>
              <a
                href="#canli-demo"
                className="rounded-lg border border-white/15 px-5 py-3 text-sm font-semibold text-zinc-200 transition hover:bg-white/5"
              >
                Canlı Demoyu Dene
              </a>
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-zinc-500">
              <span>✅ Premiere Pro 25.6+</span>
              <span>✅ Windows & macOS</span>
              <span>✅ Kapalı kod yok, tamamen incelenebilir</span>
            </div>
          </div>
          <div className="flex flex-col items-center">
            <div
              className="flex justify-center px-6 py-10"
              style={{
                backgroundImage: "radial-gradient(rgba(255,255,255,0.09) 1px, transparent 1px)",
                backgroundSize: "18px 18px",
              }}
            >
              <FxConsoleDemo />
            </div>
            <div className="mt-4 flex items-center gap-2 text-xs">
              {(["blur", "Fast Blur", "frac"] as const).map((q) => (
                <button
                  key={q}
                  onClick={() => window.dispatchEvent(new CustomEvent("fx-demo:set-query", { detail: q }))}
                  className="border border-white/10 bg-white/[0.04] px-2.5 py-1 text-zinc-400 transition hover:border-white/25 hover:text-white"
                  style={{ fontFamily: '"Segoe UI", -apple-system, system-ui, sans-serif' }}
                >
                  {q}
                </button>
              ))}
              <span className="ml-1 text-zinc-600">Ctrl+Alt+Space → odaklanır</span>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT MAPS FROM AE */}
      <section className="border-y border-white/5 bg-white/[0.02] px-6 py-16">
        <div className="mx-auto max-w-4xl text-center">
          <h3 className="text-sm font-semibold uppercase tracking-widest text-cyan-300">Nasıl çalışıyor?</h3>
          <p className="mt-4 text-xl text-zinc-300">
            After Effects'te <kbd className="rounded bg-white/10 px-2 py-0.5 text-zinc-100">Ctrl/Cmd + Space</kbd>'e
            basıp efekt yazıp Enter'a basıyorsanız — FX Console (TR) ile Premiere Pro'da aynı akışı
            yaşarsınız: <strong className="text-white">klip seç → ara → Enter → efekt eklendi.</strong>
          </p>
        </div>
      </section>

      {/* FEATURES */}
      <section id="ozellikler" className="px-6 py-24">
        <div className="mx-auto max-w-6xl">
          <SectionTitle
            eyebrow="Özellikler"
            title="FX Console'un her yeteneği, birebir Premiere'e taşındı"
            desc="Arayüzden klavye kısayollarına, favorilere ve alias sistemine kadar tüm iş akışı aynı mantıkla yeniden kuruldu."
          />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition hover:border-violet-500/40 hover:bg-white/[0.05]"
              >
                <div className="mb-3 text-2xl">{f.icon}</div>
                <h3 className="font-semibold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COMPARISON TABLE */}
      <section className="border-y border-white/5 bg-white/[0.02] px-6 py-24">
        <div className="mx-auto max-w-4xl">
          <SectionTitle eyebrow="Karşılaştırma" title="FX Console (AE) vs. FX Console (TR / Premiere)" />
          <div className="overflow-hidden rounded-2xl border border-white/10">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="bg-white/[0.04] text-zinc-300">
                  <th className="px-4 py-3 font-semibold">Özellik</th>
                  <th className="px-4 py-3 font-semibold">After Effects — FX Console</th>
                  <th className="px-4 py-3 font-semibold">Premiere Pro — FX Console (TR)</th>
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row, i) => (
                  <tr key={row[0]} className={i % 2 === 0 ? "bg-transparent" : "bg-white/[0.02]"}>
                    <td className="px-4 py-3 font-medium text-zinc-200">{row[0]}</td>
                    <td className="px-4 py-3 text-zinc-400">{row[1]}</td>
                    <td className="px-4 py-3 text-zinc-400">{row[2]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* INSTALL */}
      <section id="kurulum" className="px-6 py-24">
        <div className="mx-auto max-w-4xl">
          <SectionTitle
            eyebrow="Kurulum"
            title="5 adımda kurulum"
            desc="UXP, Adobe'nin eklentiler için yeni standardı. Kurulum tek seferlik ve 5 dakikanızı alır."
          />
          <ol className="space-y-5">
            {installSteps.map((step, i) => (
              <li key={step.title} className="flex gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 font-bold text-white">
                  {i + 1}
                </div>
                <div>
                  <h4 className="font-semibold text-white">{step.title}</h4>
                  <p className="mt-1 text-sm text-zinc-400">{step.desc}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="mt-8 flex justify-center">
            <a
              href="/downloads/fx-console-tr-premiere-plugin.zip"
              download
              className="rounded-lg bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-500/30 transition hover:opacity-90"
            >
              ⬇ manifest.json dahil eklenti klasörünü indir (.zip)
            </a>
          </div>
        </div>
      </section>

      {/* LIMITATIONS - honesty section about global hotkey */}
      <section id="sinirlar" className="border-y border-white/5 bg-amber-500/[0.04] px-6 py-24">
        <div className="mx-auto max-w-4xl">
          <div className="rounded-2xl border border-amber-400/20 bg-amber-400/5 p-8">
            <h3 className="flex items-center gap-2 text-xl font-bold text-amber-200">
              ⚠ "Her yerde Ctrl+Alt+Space" hakkında dürüst bir not
            </h3>
            <p className="mt-4 leading-relaxed text-zinc-300">
              After Effects'teki FX Console native bir eklenti olduğu için işletim sistemi
              seviyesinde genel (global) bir klavye kısayolu kurabiliyor ve AE'nin{" "}
              <strong className="text-white">herhangi bir panelinde</strong> odak nerede olursa
              olsun açılabiliyor. Premiere Pro'nun yeni nesil eklenti platformu{" "}
              <strong className="text-white">UXP</strong>, bunu yazdığımız tarih itibarıyla bu
              yeteneği henüz desteklemiyor — Adobe'nin resmi dokümantasyonu bunu açıkça belirtiyor
              ("Keyboard shortcuts are not available in Premiere yet") ve eklenti komutları, Edit →
              Keyboard Shortcuts panelinde de listelenmiyor.
            </p>
            <p className="mt-4 leading-relaxed text-zinc-300">
              Bu yüzden FX Console (TR) dürüst bir mühendislik kararıyla şunu sunuyor: paneli dock
              edip açık tutuyorsunuz; panel odaktayken{" "}
              <kbd className="rounded bg-white/10 px-2 py-0.5">Ctrl+Alt+Space</kbd> (özelleştirilebilir)
              arama kutusuna anında atlıyor. Adobe global kısayol desteğini UXP'ye eklediğinde,
              eklenti kod değişikliği gerekmeden bunu otomatik olarak devralacak şekilde
              yapılandırılmıştır.
            </p>
          </div>
        </div>
      </section>

      {/* ARCHITECTURE */}
      <section className="px-6 py-24">
        <div className="mx-auto max-w-4xl">
          <SectionTitle eyebrow="Mimari" title="Gerçek Premiere API'si, mockup değil" />
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <h4 className="font-semibold text-cyan-300">Efekt kataloğu</h4>
              <p className="mt-2 text-sm text-zinc-400">
                <code className="text-zinc-300">VideoFilterFactory.getMatchNames()</code> /{" "}
                <code className="text-zinc-300">getDisplayNames()</code> ve{" "}
                <code className="text-zinc-300">AudioFilterFactory.getDisplayNames()</code> ile
                Premiere'in tüm video ve ses efekt kataloğu canlı olarak çekilir.
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <h4 className="font-semibold text-cyan-300">Efekt uygulama</h4>
              <p className="mt-2 text-sm text-zinc-400">
                <code className="text-zinc-300">trackItem.getComponentChain()</code> →{" "}
                <code className="text-zinc-300">VideoFilterFactory.createComponent(matchName)</code> →{" "}
                <code className="text-zinc-300">project.executeTransaction(...)</code> ile seçili
                klip(ler)e gerçek efekt eklenir.
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <h4 className="font-semibold text-cyan-300">Kalıcılık</h4>
              <p className="mt-2 text-sm text-zinc-400">
                Favoriler, alias'lar, 1-9 slotları ve gizlenenler eklenti içinde{" "}
                <code className="text-zinc-300">localStorage</code> ile saklanır; panodan
                içe/dışa aktarılabilir.
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <h4 className="font-semibold text-cyan-300">Platform</h4>
              <p className="mt-2 text-sm text-zinc-400">
                Manifest v5, <code className="text-zinc-300">panel</code> +{" "}
                <code className="text-zinc-300">command</code> entrypoint'leri ile Premiere Pro
                25.6+ üzerinde çalışacak şekilde yazılmıştır.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 px-6 py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-sm text-zinc-500 sm:flex-row">
          <div className="flex items-center gap-2">
            <img src="/images/fxconsole-icon.png" alt="" className="h-6 w-6 rounded" />
            <span>FX Console TR — Adobe veya Video Copilot ile bağlantılı değildir, bağımsız bir topluluk projesidir.</span>
          </div>
          <a
            href="/downloads/fx-console-tr-premiere-plugin.zip"
            download
            className="font-semibold text-violet-300 hover:text-violet-200"
          >
            Eklentiyi indir →
          </a>
        </div>
      </footer>
    </div>
  );
}
