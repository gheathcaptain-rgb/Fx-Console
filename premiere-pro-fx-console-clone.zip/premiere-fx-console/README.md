# FX Palette (TR) — Premiere Pro için ücretsiz UXP eklentisi

After Effects'in **FX Console** deneyiminin Premiere Pro'ya uyarlanmış, bağımsız ve ücretsiz
klonu: `Ctrl+Alt+Space` → efekt/preset adını yaz → `Enter` → seçili klibe anında uygulanır.

Görünüm, `FX Palette for Premiere — görünümün metin tarifi` dosyasına birebir uyar:
**384×44 koyu bar (`#1E1F22`), Segoe UI, altında açılan iki gruplu liste** — başka hiçbir şey yok.

## Görünüm

- **Bar (384×44):** solda büyüteç, ortada kenarlıksız arama alanı (boşken soluk `Fx` yazar),
  sağda 5 düz ikon: snapshot · galeri · dışa aktar · ayarlar (dişli) · uygula.
- **Liste:** aynı genişlikte, zemin `#18191B`. İki grup, her zaman bu sırada:
  - 🔴 **Presets** — 8 px kırmızı nokta (`#EF4444`), sağda eşleşme sayısı. Özel presetlerin.
  - 🔵 **Effects** — 8 px mavi nokta (`#3B82F6`), sağda eşleşme sayısı. Tüm video + ses efektleri.
- **Satır (31 px):** solda yıldız (favori = dolu altın `#F2B84B`), ortada kalın efekt adı,
  sağda tür etiketi (`Video`/`Audio` → `#93C5FD`, `Preset` → `#FCA5A5`).
- **Seçili satır:** tam genişlikte düz `#0078D7`, beyaz yazı. En fazla 8 satır + 3 px ince kaydırma.
- **Ayarlar (dişli):** 152 px çekmece — 3 onay kutusu + Rebuild / Self-Test / Clear + önek bilgisi
  (`v:` video · `a:` ses · `p:` preset).
- **Toast:** barın altında, duruma göre yeşil/hardal/bordo.

## Gereksinimler

- **Adobe Premiere Pro 25.6+** (UXP desteği bu sürümle geldi).
- **UXP Developer Tool (UDT)** + Premiere tercihlerinde **Plugins > Enable Developer Mode**.

## Kurulum

1. UDT'yi kurun, Premiere'de geliştirici modunu açıp Premiere'i yeniden başlatın.
2. UDT'de **Add Plugin** → bu klasördeki `manifest.json` → **Load**.
3. Premiere'de **Window > UXP Plugins > FX Console (TR) > FX Console** ile paneli açıp dock edin.

## Kullanım

1. Zaman çizelgesinde klip(ler)i seçin.
2. Panele tıklayıp yazmaya başlayın (`blur`, `Fast Blur`, `frac`, `gb`…).
3. ↑/↓ ile gezinin, **Enter** ile uygulayın (**Shift+Enter** = açık tutup uygulamaya devam).
4. Önekler: `v:blur` (yalnız video), `a:rev` (yalnız ses), `p:glow` (yalnız presetler).
5. Satır yıldızına tıklayınca **favori** olur (en üstte sıralanır).
6. Satıra **sağ tıklayınca**: favori · takma ad (alias) · **Preset grubuna kaydet** · gizle.
7. Dişli → ayarlar: uygula sonrası kapat, dışarı tıklayınca kapat, kısayol davranışı + panel
   kısayolunu değiştirme + Rebuild / Self-Test / Clear.

## Preset grubu nasıl beslenir?

UXP, yazım tarihi itibarıyla Premiere'in **preset binini listeleyen bir API sunmuyor**
(efekt katalog API'si var: `VideoFilterFactory` / `AudioFilterFactory`, preset API'si yok).
Bu yüzden Presets grubu, eklenti içinde sakladığınız özel presetlerle beslenir: herhangi bir
sonuca sağ tıklayıp **"Preset grubuna kaydet"** deyin, o andan itibaren kırmızı noktalı grupta
listelenir ve tek tuşla uygulanır. Adobe preset listeleme API'sini açtığında aynı grup,
kodun `presetItems()` katmanı üzerinden Premiere preset bininden **otomatik** beslenecek
şekilde yazılmıştır.

## "Ctrl+Alt+Space her yerde" hakkında dürüst not

AE'deki FX Console native olduğu için OS seviyesinde global kısayol kurabiliyor. Premiere **UXP**
ise henüz uygulama geneli özel kısayolu desteklemiyor (Adobe: *"Keyboard shortcuts are not
available in Premiere yet"*). Bu yüzden kısayol **panel odaktayken** aramaya atlar
(ayarlanabilir), ayrıca `Window > UXP Plugins` menü komutu her zaman kullanılabilir. Adobe destek
eklediğinde `manifest.json` → `entrypoints[].shortcut` üzerinden devralınır.

## Teknik mimari

- `manifest.json`: UXP manifest v5, `panel` + `command` entrypoint'leri, Premiere 25.6+.
- `index.html` / `css/style.css`: tarif dosyasındaki hex ve ölçülerle piksel-birebir arayüz.
- `js/main.js`:
  - Katalog: `VideoFilterFactory.getMatchNames()/getDisplayNames()` +
    `AudioFilterFactory.getDisplayNames()` (canlı, Premiere'in gerçek listesi).
  - Uygulama: `getComponentChain()` → `createComponent()` →
    `project.lockedAccess(() => project.executeTransaction(...))` (resmi Adobe deseni).
  - Arama: tam → başlangıç → kelime başı → alt dize → baş harf → sıralı alt küme skorlaması,
    favoriler önce.
  - Tercihler (favori, alias, gizlenenler, presetler, kısayol): eklenti `localStorage`'ında.

## Bilinen sınırlamalar

- Global (panel odağından bağımsız) kısayol UXP'de yok (yukarıya bakın).
- Snapshot/galeri ikonları yer tutucudur; kare yakalama `Exporter.exportSequenceFrame()` ile
  planlanmaktadır.
