/**
 * FX Palette (TR) — Premiere Pro UXP eklentisi
 * Tarif dosyasına birebir: 384x44 bar, Presets (kırmızı nokta) +
 * Effects (mavi nokta) grupları, seçim #0078D7, Segoe UI.
 *
 * Efekt kataloğu resmi premierepro UXP API'sinden canlı çekilir:
 *   VideoFilterFactory.getMatchNames/getDisplayNames
 *   AudioFilterFactory.getDisplayNames
 * Preset grubu = kullanıcının kaydettiği özel presetler (localStorage).
 *   UXP şu an preset binini listeleyen bir API sunmadığı için presetler
 *   eklenti içinde saklanır; Adobe bu API'yi açtığında aynı grup
 *   otomatik olarak Premiere preset bininden beslenecek şekilde yazıldı.
 *
 * Global kısayol notu: UXP Premiere'de uygulama geneli özel kısayol
 * desteklemez ("Keyboard shortcuts are not available in Premiere yet").
 * Bu yüzden Ctrl+Alt+Space panel odaktayken aramaya atlar; Adobe destek
 * eklediğinde manifest shortcut alanından devralınır.
 */

const { entrypoints } = require("uxp");
const ppro = require("premierepro");

const STORAGE_KEY = "fxpalette_tr_state_v1";
const MAX_VIS_ROWS = 8;

let allEffects = []; // {kind:'video'|'audio', matchName?, displayName, id}
let catalogLoaded = false;

let state = {
  favorites: [],
  aliases: {},
  hidden: [],
  customPresets: [], // {id, name, baseId}
  hotkey: { ctrlKey: true, altKey: true, shiftKey: false, key: " " },
  closeAfterApply: true,
  closeOnOutside: true,
  shortcutCloses: true,
};

let activeFlat = 0;
let lastFlat = []; // visible flat rows: {item, group:'preset'|'effect'}
let contextTarget = null;
let toastTimer = null;
let el = {};

// ---------------------------------------------------------------- persistence
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) state = Object.assign({}, state, JSON.parse(raw));
  } catch (e) { console.warn("palette: state okunamadı", e); }
}
function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch (e) { console.warn("palette: state yazılamadı", e); }
}
function effectId(e) { return e.kind + ":" + (e.matchName || e.displayName); }

// ---------------------------------------------------------------- catalog
async function loadCatalog() {
  try {
    const [videoMatch, videoDisp, audioDisp] = await Promise.all([
      ppro.VideoFilterFactory.getMatchNames(),
      ppro.VideoFilterFactory.getDisplayNames(),
      ppro.AudioFilterFactory.getDisplayNames(),
    ]);
    const vids = videoMatch.map((m, i) => ({ kind: "video", matchName: m, displayName: videoDisp[i] || m }));
    const auds = audioDisp.map((d) => ({ kind: "audio", displayName: d }));
    allEffects = [...vids, ...auds].map((e) => Object.assign({}, e, { id: effectId(e) }));
    catalogLoaded = true;
    toast(`${allEffects.length} efekt yüklendi`, "ok");
  } catch (err) {
    catalogLoaded = false;
    console.error(err);
    toast("Katalog yüklenemedi — Premiere Pro 25.6+ gerekli", "err");
  }
}

function presetItems() {
  return state.customPresets
    .map((p) => {
      const base = allEffects.find((e) => e.id === p.baseId);
      if (!base && !p.freeName) return null;
      return {
        kind: "preset",
        displayName: p.name,
        baseId: p.baseId,
        id: "preset:" + p.id,
        baseMissing: !base,
      };
    })
    .filter(Boolean);
}

// ---------------------------------------------------------------- fuzzy search
function scoreAgainst(query, text) {
  if (!query) return 0;
  const q = query.toLowerCase(), t = (text || "").toLowerCase();
  if (!t) return -1;
  if (t === q) return 1000;
  if (t.startsWith(q)) return 900;
  const words = t.split(/[\s&/_-]+/).filter(Boolean);
  if (words.some((w) => w.startsWith(q))) return 800;
  if (t.includes(q)) return 650;
  const initials = words.map((w) => w[0]).join("");
  if (initials.includes(q)) return 500;
  let ti = 0;
  for (let qi = 0; qi < q.length; qi++) {
    const idx = t.indexOf(q[qi], ti);
    if (idx === -1) return -1;
    ti = idx + 1;
  }
  return 200;
}

function rankItems(items, rest) {
  return items
    .map((it) => {
      const alias = state.aliases[it.id] || "";
      const cands = [it.displayName, it.matchName || "", alias];
      let best = -1;
      for (const c of cands) {
        const s = scoreAgainst(rest, c);
        if (s > best) best = s;
      }
      return { it, score: best };
    })
    .filter((r) => r.score >= 0)
    .sort((a, b) => {
      const fa = state.favorites.includes(a.it.id) ? 1 : 0;
      const fb = state.favorites.includes(b.it.id) ? 1 : 0;
      if (fa !== fb) return fb - fa;
      if (b.score !== a.score) return b.score - a.score;
      return a.it.displayName.localeCompare(b.it.displayName);
    })
    .map((r) => r.it);
}

function computeResults() {
  const q = el.searchInput.value.trim();
  if (!q) return { presets: [], effects: [], pTotal: 0, eTotal: 0 };
  let scope = "all", rest = q;
  const m = q.match(/^\s*(v|a|p)\s*:\s*(.*)$/i);
  if (m) {
    scope = m[1].toLowerCase() === "v" ? "video" : m[1].toLowerCase() === "a" ? "audio" : "preset";
    rest = m[2];
  }
  if (!rest) return { presets: [], effects: [], pTotal: 0, eTotal: 0 };

  const presets = scope === "video" || scope === "audio" ? [] : rankItems(
    presetItems().filter((p) => !state.hidden.includes(p.id)), rest);
  const effects = scope === "preset" ? [] : rankItems(
    allEffects.filter((e) => {
      if (state.hidden.includes(e.id)) return false;
      if (scope === "video") return e.kind === "video";
      if (scope === "audio") return e.kind === "audio";
      return true;
    }), rest);
  return { presets, effects, pTotal: presets.length, eTotal: effects.length };
}

// ---------------------------------------------------------------- apply
async function getSelection() {
  const project = await ppro.Project.getActiveProject();
  if (!project) throw new Error("Aktif proje yok");
  const sequence = await project.getActiveSequence();
  if (!sequence) throw new Error("Aktif sekans yok");
  const selection = await sequence.getSelection();
  const trackItems = await selection.getTrackItems();
  return { project, trackItems };
}

function resolveBase(item) {
  if (item.kind !== "preset") return item;
  return allEffects.find((e) => e.id === item.baseId) || null;
}

async function applyItem(item, keepOpen) {
  const base = resolveBase(item);
  if (!base) { toast("Preset kaynağı bulunamadı", "err"); return false; }
  try {
    const { project, trackItems } = await getSelection();
    if (!trackItems || !trackItems.length) { toast("Önce zaman çizelgesinde klip seçin", "err"); return false; }
    const targets = trackItems.filter((ti) =>
      base.kind === "video" ? ti instanceof ppro.VideoClipTrackItem : ti instanceof ppro.AudioClipTrackItem);
    if (!targets.length) { toast(base.kind === "video" ? "Video klip seçin" : "Ses klibi seçin", "err"); return false; }

    let ok = 0;
    for (const ti of targets) {
      try {
        const chain = await ti.getComponentChain();
        const comp = base.kind === "video"
          ? await ppro.VideoFilterFactory.createComponent(base.matchName)
          : await ppro.AudioFilterFactory.createComponentByDisplayName(base.displayName, ti);
        let done = false;
        project.lockedAccess(() => {
          done = project.executeTransaction((ca) => {
            ca.addAction(chain.createInsertComponentAction(comp, chain.getComponentCount()));
          }, "FX Palette: " + base.displayName);
        });
        if (done) ok++;
      } catch (e) { console.error(e); }
    }
    if (ok > 0) {
      toast(`"${item.displayName}" → ${ok}/${targets.length} klibe eklendi`, "ok");
      if (!keepOpen && state.closeAfterApply) { el.searchInput.value = ""; render(); }
      return true;
    }
    toast("Uygulanamadı", "err");
    return false;
  } catch (err) {
    console.error(err);
    toast("Hata: " + (err && err.message ? err.message : err), "err");
    return false;
  }
}

// ---------------------------------------------------------------- UI
function cache() {
  ["searchInput", "dropdown", "groups", "settingsDrawer", "toast", "contextMenu",
   "settingsBtn", "snapBtn", "galleryBtn", "exportBtn", "sendBtn", "bar",
   "rebuildBtn", "selfTestBtn", "clearBtn", "hotkeyInput"].forEach((id) => { el[id] = document.getElementById(id); });
}

function toast(msg, kind) {
  kind = kind || "ok";
  el.toast.textContent = msg;
  el.toast.className = kind;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.toast.className = "hidden"; }, 2600);
}

function starSVG(filled, color, opacity) {
  return `<svg width="10" height="10" viewBox="0 0 24 24" fill="${filled ? color : "none"}" stroke="${color}" stroke-width="2" style="opacity:${opacity}">` +
    `<path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z" stroke-linejoin="round"/></svg>`;
}

function tagFor(item) {
  if (item.kind === "preset") return ["preset", "Preset"];
  return [item.kind, item.kind === "video" ? "Video" : "Audio"];
}

function render() {
  const q = el.searchInput.value.trim();
  if (!q || !el.settingsDrawer.classList.contains("hidden") === false && false) { /* noop */ }
  if (!q) {
    el.dropdown.classList.add("hidden");
    lastFlat = [];
    activeFlat = 0;
    return;
  }
  const { presets, effects, pTotal, eTotal } = computeResults();
  const pVis = presets.slice(0, MAX_VIS_ROWS);
  const eVis = effects.slice(0, MAX_VIS_ROWS - pVis.length);
  lastFlat = [...pVis.map((it) => ({ item: it, group: "preset" })), ...eVis.map((it) => ({ item: it, group: "effect" }))];
  activeFlat = Math.min(activeFlat < 0 ? 0 : activeFlat, Math.max(0, lastFlat.length - 1));

  el.groups.innerHTML = "";
  if (!lastFlat.length) {
    el.groups.appendChild(groupHeader("#EF4444", "Presets", 0));
    el.groups.appendChild(groupHeader("#3B82F6", "Effects", 0));
    const d = document.createElement("div");
    d.className = "empty-note";
    d.textContent = "no match — try another name";
    el.groups.appendChild(d);
  } else {
    if (pVis.length || pTotal) {
      el.groups.appendChild(groupHeader("#EF4444", "Presets", pTotal));
      pVis.forEach((it, i) => el.groups.appendChild(rowEl(it, i)));
    }
    if (eVis.length || eTotal) {
      el.groups.appendChild(groupHeader("#3B82F6", "Effects", eTotal));
      eVis.forEach((it, i) => el.groups.appendChild(rowEl(it, pVis.length + i)));
    }
  }
  el.dropdown.classList.remove("hidden");
}

function groupHeader(dot, title, count) {
  const h = document.createElement("div");
  h.className = "group-hdr";
  h.innerHTML = `<span class="dot" style="background:${dot}"></span>` +
    `<span class="gtitle">${title}</span>` +
    `<span class="gcount${count === 0 ? " zero" : ""}">${count}</span>`;
  return h;
}

function rowEl(item, flatIndex) {
  const selected = flatIndex === activeFlat;
  const isFav = state.favorites.includes(item.id);
  const starColor = selected ? (isFav ? "#FFE083" : "rgba(255,255,255,0.72)") : isFav ? "#F2B84B" : "#757882";
  const [tagCls, tagTxt] = tagFor(item);
  const alias = state.aliases[item.id];
  const label = item.displayName + (alias ? ` (${alias})` : "") + (item.baseMissing ? " — kaynak yok" : "");

  const row = document.createElement("div");
  row.className = "row" + (selected ? " selected" : "");
  row.innerHTML =
    `<button class="star" style="opacity:${isFav || selected ? 1 : 0.33}">${starSVG(isFav || selected, starColor, 1)}</button>` +
    `<span class="nm" title="${label.replace(/"/g, "&quot;")}">${label}</span>` +
    `<span class="tag ${tagCls}">${tagTxt}</span>`;

  row.querySelector(".star").addEventListener("click", (ev) => {
    ev.stopPropagation();
    toggleFav(item.id);
  });
  row.addEventListener("click", () => applyItem(item, false));
  row.addEventListener("mouseenter", () => {
    if (activeFlat !== flatIndex) {
      activeFlat = flatIndex;
      paintSelection();
    }
  });
  row.addEventListener("contextmenu", (ev) => {
    ev.preventDefault();
    openContext(ev.clientX, ev.clientY, item);
  });
  return row;
}

function paintSelection() {
  // seçim + yıldız renklerini tazelemek için tam çizim (liste küçük, ucuz)
  render();
}

function toggleFav(id) {
  state.favorites = state.favorites.includes(id)
    ? state.favorites.filter((f) => f !== id)
    : [id, ...state.favorites];
  saveState();
  render();
}

// ---------------------------------------------------------------- context
function openContext(x, y, item) {
  contextTarget = item;
  el.contextMenu.style.left = x + "px";
  el.contextMenu.style.top = y + "px";
  el.contextMenu.classList.remove("hidden");
}
function closeContext() { el.contextMenu.classList.add("hidden"); contextTarget = null; }

function handleContext(action) {
  const item = contextTarget;
  if (!item) return;
  if (action === "favorite") toggleFav(item.id);
  else if (action === "alias") {
    const cur = state.aliases[item.id] || "";
    const v = window.prompt(`"${item.displayName}" için takma ad:`, cur);
    if (v !== null) {
      if (v.trim()) state.aliases[item.id] = v.trim();
      else delete state.aliases[item.id];
      saveState(); render();
    }
  } else if (action === "preset") {
    if (item.kind === "preset") { toast("Bu zaten bir preset", "warn"); }
    else {
      const name = window.prompt("Preset adı:", item.displayName);
      if (name && name.trim()) {
        state.customPresets.unshift({ id: "c" + Date.now(), name: name.trim(), baseId: item.id });
        saveState(); render();
        toast(`"${name.trim()}" Presets grubuna eklendi`, "ok");
      }
    }
  } else if (action === "hide") {
    if (!state.hidden.includes(item.id)) state.hidden.push(item.id);
    saveState(); render();
  }
  closeContext();
}

// ---------------------------------------------------------------- hotkey
function hotkeyLabel(hk) {
  const p = [];
  if (hk.ctrlKey) p.push("Ctrl");
  if (hk.altKey) p.push("Alt");
  if (hk.shiftKey) p.push("Shift");
  p.push(hk.key === " " ? "Space" : String(hk.key).toUpperCase());
  return p.join(" + ");
}
function matchHotkey(ev, hk) {
  const k = ev.key === " " ? " " : String(ev.key).toLowerCase();
  const hkKey = hk.key === " " ? " " : String(hk.key).toLowerCase();
  return !!ev.ctrlKey === !!hk.ctrlKey && !!ev.altKey === !!hk.altKey &&
    !!ev.shiftKey === !!hk.shiftKey && k === hkKey;
}
function focusSearch() { el.searchInput.focus(); el.searchInput.select(); }

// ---------------------------------------------------------------- settings UI
function paintChecks() {
  el.settingsDrawer.querySelectorAll(".checkbox").forEach((c) => {
    c.classList.toggle("checked", !!state[c.dataset.key]);
    c.textContent = state[c.dataset.key] ? "✓" : "";
  });
}

function setupEvents() {
  el.searchInput.addEventListener("input", () => {
    activeFlat = 0;
    el.settingsDrawer.classList.add("hidden");
    el.settingsBtn.classList.remove("on");
    render();
  });
  el.searchInput.addEventListener("focus", () => el.bar.classList.add("focused"));
  el.searchInput.addEventListener("blur", () => el.bar.classList.remove("focused"));

  document.addEventListener("keydown", (ev) => {
    if (matchHotkey(ev, state.hotkey) && document.activeElement !== el.hotkeyInput) {
      ev.preventDefault();
      if (state.shortcutCloses && document.activeElement === el.searchInput && el.searchInput.value) {
        el.searchInput.value = "";
        el.searchInput.blur();
        render();
      } else {
        el.settingsDrawer.classList.add("hidden");
        el.settingsBtn.classList.remove("on");
        focusSearch();
      }
      return;
    }
    if (document.activeElement === el.searchInput) {
      if (ev.key === "ArrowDown") { ev.preventDefault(); if (lastFlat.length) { activeFlat = Math.min(activeFlat + 1, lastFlat.length - 1); render(); } }
      else if (ev.key === "ArrowUp") { ev.preventDefault(); if (lastFlat.length) { activeFlat = Math.max(activeFlat - 1, 0); render(); } }
      else if (ev.key === "Enter") { ev.preventDefault(); const r = lastFlat[activeFlat]; if (r) applyItem(r.item, ev.shiftKey); }
      else if (ev.key === "Escape") {
        if (!el.settingsDrawer.classList.contains("hidden")) { el.settingsDrawer.classList.add("hidden"); el.settingsBtn.classList.remove("on"); }
        else { el.searchInput.value = ""; render(); }
      }
    } else if (ev.key === "Escape") {
      if (!el.settingsDrawer.classList.contains("hidden")) { el.settingsDrawer.classList.add("hidden"); el.settingsBtn.classList.remove("on"); }
      closeContext();
    }
  });

  document.addEventListener("click", (ev) => {
    if (!el.contextMenu.contains(ev.target)) closeContext();
  });
  el.toast.addEventListener("click", () => { el.toast.className = "hidden"; });

  el.settingsBtn.addEventListener("click", () => {
    const opening = el.settingsDrawer.classList.contains("hidden");
    el.settingsDrawer.classList.toggle("hidden");
    el.settingsBtn.classList.toggle("on", opening);
    if (opening) {
      el.dropdown.classList.add("hidden");
      paintChecks();
      el.hotkeyInput.value = hotkeyLabel(state.hotkey);
    } else if (el.searchInput.value.trim()) {
      render();
    }
  });

  el.settingsDrawer.querySelectorAll(".set-row").forEach((row) => {
    row.addEventListener("click", (ev) => {
      ev.preventDefault();
      const key = row.querySelector(".checkbox").dataset.key;
      state[key] = !state[key];
      saveState();
      paintChecks();
    });
  });

  el.rebuildBtn.addEventListener("click", async () => { toast("Katalog yenileniyor..."); await loadCatalog(); render(); });
  el.selfTestBtn.addEventListener("click", async () => {
    try {
      const vm = await ppro.VideoFilterFactory.getMatchNames();
      const am = await ppro.AudioFilterFactory.getDisplayNames();
      toast(`Self-Test OK — ${vm.length} video, ${am.length} ses`, "ok");
    } catch (e) { toast("Self-Test başarısız: " + e, "err"); }
  });
  el.clearBtn.addEventListener("click", () => {
    state.hidden = [];
    saveState(); render();
    toast("Gizlenenler temizlendi", "ok");
  });

  el.hotkeyInput.addEventListener("keydown", (ev) => {
    ev.preventDefault();
    if (["Control", "Alt", "Shift", "Meta"].includes(ev.key)) return;
    state.hotkey = { ctrlKey: ev.ctrlKey, altKey: ev.altKey, shiftKey: ev.shiftKey, key: ev.key };
    el.hotkeyInput.value = hotkeyLabel(state.hotkey);
    saveState();
  });

  el.sendBtn.addEventListener("click", () => {
    const r = lastFlat[activeFlat];
    if (r) applyItem(r.item, false);
    else toast("Önce bir sonuç seçin", "warn");
  });
  el.snapBtn.addEventListener("click", () => toast("Snapshot yakında: Exporter.exportSequenceFrame ile eklenecek", "warn"));
  el.galleryBtn.addEventListener("click", () => toast("Galeri yakında", "warn"));
  el.exportBtn.addEventListener("click", () => {
    try {
      const data = JSON.stringify(state, null, 2);
      if (navigator.clipboard) navigator.clipboard.writeText(data);
      toast("Ayarlar panoya kopyalandı", "ok");
    } catch (e) { toast("Kopyalanamadı: " + e, "err"); }
  });

  el.contextMenu.querySelectorAll("button").forEach((b) =>
    b.addEventListener("click", () => handleContext(b.dataset.action)));
}

// ---------------------------------------------------------------- boot
let booted = false;
async function init() {
  if (booted) return;
  booted = true;
  cache();
  loadState();
  setupEvents();
  paintChecks();
  el.hotkeyInput.value = hotkeyLabel(state.hotkey);
  await loadCatalog();
  focusSearch();
}

entrypoints.setup({
  plugin: {
    create() { console.log("FX Palette (TR) created"); },
    destroy() { console.log("FX Palette (TR) destroyed"); },
  },
  panels: {
    fxConsolePanel: {
      create() { return init(); },
      show() { if (booted) focusSearch(); },
    },
  },
  commands: {
    focusFxConsole: () => { if (booted) focusSearch(); },
  },
});

document.addEventListener("DOMContentLoaded", () => { if (!booted) init(); });
